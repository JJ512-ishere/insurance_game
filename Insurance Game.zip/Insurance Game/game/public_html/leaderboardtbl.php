<!DOCTYPE html>
<html>
<head>
    <title>Leaderboard</title>
    <link rel="stylesheet" href="assets/css/php.css">
</head>
<body>
    <h1>Leaderboard</h1>

    <?php
    // Database credentials
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $database = "game";
    $port = "3306";

    // Create a database connection
    $conn = mysqli_connect('localhost', 'root', '', 'game',3306);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve team names and associated values from the database
    $sql = "SELECT * FROM leaderboard";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<table>";
        echo "<thead>";
        echo "<tr>";
        echo "<th>Team Name</th>";
        echo "<th>Asset Value</th>";
        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";

        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row['Team_Name'] . "</td>";
            echo "<td>" . $row['Asset_Value'] . "</td>";
            echo "</tr>";
        }
        
        echo "</tbody>";
        echo "</table>";
    } else {
        echo "No teams found in the database.";
    }

    $conn->close();
    ?>
</body>
</html>
