<!DOCTYPE html>
<html lang="en">

<head>
    <title>Asset Master Table</title>
</head>

<body>

    <?php
    ini_set('display_errors', 1);
    error_reporting(E_ALL);

    // Database credentials
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $database = "game";
    $port = "3306";

    // Create a database connection
    $conn = mysqli_connect($hostname, $username, $password, $database, $port);

    // Check if the connection was successful
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Fetch asset master data from the database
    $query = "SELECT * FROM AssetMaster";
    $result = mysqli_query($conn, $query);

    // Generate HTML table rows dynamically
    echo "<table>";
    echo "<thead>";
    echo "<tr>";
    echo "<th>Asset Code</th>";
    echo "<th>Asset Description</th>";
    echo "<th>Asset</th>";
    echo "<th>Location</th>";
    echo "<th>Asset Value Year 1</th>";
    echo "<th>Asset Value Year 2</th>";
    echo "<th>Asset Value Year 3</th>";
    echo "<th>Asset Value Year 4</th>";
    echo "<th>Asset Value Year 5</th>";
    echo "<th>Life of the Asset</th>";
    echo "</tr>";
    echo "</thead>";
    echo "<tbody>";

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row['Asset_Code'] . "</td>";
            echo "<td>" . $row['Asset_Description'] . "</td>";
            echo "<td>" . $row['Asset'] . "</td>";
            echo "<td>" . $row['Location'] . "</td>";
            echo "<td>" . $row['Asset_Value_Year_1'] . "</td>";
            echo "<td>" . $row['Asset_Value_Year_2'] . "</td>";
            echo "<td>" . $row['Asset_Value_Year_3'] . "</td>";
            echo "<td>" . $row['Asset_Value_Year_4'] . "</td>";
            echo "<td>" . $row['Asset_Value_Year_5'] . "</td>";
            echo "<td>" . $row['Life_of_the_Asset'] . "</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='10'>No records found</td></tr>";
    }

    echo "</tbody>";
    echo "</table>";

    // Close the database connection
    mysqli_close($conn);
    ?>
</body>

</html>
