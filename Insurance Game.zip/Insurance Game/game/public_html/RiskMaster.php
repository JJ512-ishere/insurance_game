<!DOCTYPE html>
<html lang="en">

<head>
    <title>Risk Master Table</title>
    
</head>

<body>

    <?php
    ini_set('display_errors', 1);
    error_reporting(E_ALL);

    // Database credentials
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $database = "game";
    $port = "3306";

    // Create a database connection
    $conn = mysqli_connect($hostname, $username, $password, $database, $port);

    // Check if the connection was successful
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Fetch risk master data from the database
    $query = "SELECT * FROM RiskMaster";
    $result = mysqli_query($conn, $query);

    // Generate HTML table rows dynamically
    echo "<table>";
    echo "<thead>";
    echo "<tr>";
    echo "<th>Risk Event Code</th>";
    echo "<th>Risk Description</th>";
    echo "<th>Mapped Peril</th>";
    echo "<th>Location</th>";
    echo "<th>Peril</th>";
    echo "<th>Asset to be Impacted</th>";
    echo "<th>Risk Loss Year 1</th>";
    echo "<th>Risk Loss Year 2</th>";
    echo "<th>Risk Loss Year 3</th>";
    echo "<th>Risk Loss Year 4</th>";
    echo "<th>Risk Loss Year 5</th>";
    echo "<th>Probability</th>";
    echo "<th>Policy to be Procured</th>";
    echo "<th>Premium</th>";
    echo "</tr>";
    echo "</thead>";
    echo "<tbody>";

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row['Risk_Event_Code'] . "</td>";
            echo "<td>" . $row['Risk_Description'] . "</td>";
            echo "<td>" . $row['Mapped_Peril'] . "</td>";
            echo "<td>" . $row['Location'] . "</td>";
            echo "<td>" . $row['Peril'] . "</td>";
            echo "<td>" . $row['Asset_to_be_impacted'] . "</td>";
            echo "<td>" . $row['Risk_Loss_yr_1'] . "</td>";
            echo "<td>" . $row['Risk_Loss_yr_2'] . "</td>";
            echo "<td>" . $row['Risk_Loss_yr_3'] . "</td>";
            echo "<td>" . $row['Risk_Loss_yr_4'] . "</td>";
            echo "<td>" . $row['Risk_Loss_yr_5'] . "</td>";
            echo "<td>" . $row['Probability'] . "</td>";
            echo "<td>" . $row['Policy_to_be_procured'] . "</td>";
            echo "<td>" . $row['Premium'] . "</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='14'>No records found</td></tr>";
    }

    echo "</tbody>";
    echo "</table>";

    // Close the database connection
    mysqli_close($conn);
    ?>
</body>

</html>
