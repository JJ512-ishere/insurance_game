<!DOCTYPE html>
<html lang="en">

<head>
    <title>Insurance Game</title>
    <!-- font icons -->
    <link rel="stylesheet" href="assets/vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/main_css.css">

    <style>  
    
        /* Add CSS styles for white color */
        th, td {
            color: white;
        } 
    </style>
</head>

<body data-spy="scroll" data-target=".navbar" data-offset="40" id="home" class="dark-theme">
    <!-- ... (previous content) ... -->

        <!-- Congratulations message -->
        <div class="row mb-4">
            <div class="col-md-12">
              <center><h1>Check Your Position on the Overall Leaderboard!</h1></center>
            </div>
        </div>

        <!-- Leaderboard section -->
        <div class="row">
            <div class="col-md-12">
                <center><h2>Leaderboard</h2></center>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Position</th>
                           <th>Team Name</th>
                            <th>Asset Value</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Establish a connection to your MySQL database
                        $servername = "localhost";
                        $username = "root";
                        $password = "";
                        $dbname = "game";
                        $port = "3306";

                        $conn = new mysqli($servername, $username, $password, $dbname);

                        // Check connection
                        if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                        }

                        //Call End game procedure
                        $procedure="CALL end_game()";
                        $result = $conn->query($procedure);


                        // Fetch leaderboard data from the database
                        $sql = "SELECT Team_Name, Asset_Value FROM leaderboard ORDER BY Asset_Value DESC";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            $rank = 1;
                            while ($row = $result->fetch_assoc()) {
                                $teamName = $row["Team_Name"];
                                $score = $row["Asset_Value"];
                                echo "<tr>";
                                echo "<td>" . $rank . "</td>";
                                echo "<td>$teamName</td>";
                                echo "<td>$score</td>";
                                echo "</tr>";
                                $rank++;
                            }
                        } else {
                            echo "<tr><td colspan='3'>No data available</td></tr>";
                        }

                        $conn->close();
                        ?>
                    </tbody>
                </table>
            </div>
        </div><!-- end of leaderboard section -->

    </div><!-- end of container -->
    <!-- <center><button onclick="closeWindow()">End Game</button> -->
    <center>
    <form action='main_html.php' method='post'>
    <input type='submit' name='playagain' value='Play Again'>
    </form>    
    </center>

    <script>
    function closeWindow() {
        window.close(); // This will attempt to close the current window/tab
    }
    </script>

</body>

</html>
