<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Team Balances</title>
    <!-- Add any necessary CSS or styling -->
    <link rel="stylesheet" href="assets/css/php.css">
</head>

<body>
    <h1>Team Balances</h1>

    <?php
    ini_set('display_errors', 1);
    error_reporting(E_ALL);

    // Database credentials
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $database = "game";
    $port = "3306";

   // Create a database connection
   $conn = mysqli_connect('localhost', 'root', '', 'game',3306);

    // Check if the connection was successful
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Fetch team balance data from the database
    $query = "SELECT * from balance";
    $result = mysqli_query($conn, $query);

    // Generate HTML table rows dynamically
    if (mysqli_num_rows($result) > 0) {
        echo "<table>";
        echo "<thead>";
        echo "<tr>";
        echo "<th>Team Name</th>";
        echo "<th>Balance</th>";
        echo "<th>Asset Value</th>";
        echo "<th>Team Code</th>";
        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";

        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row['Team_Name'] . "</td>";
            echo "<td>" . $row['bal'] . "</td>";
            echo "<td>" . $row['Asset_Value'] . "</td>";
            echo "<td>" . $row['Team_Code'] . "</td>";
            echo "</tr>";
        }

        echo "</tbody>";
        echo "</table>";
    } else {
        echo "<p>No records found.</p>";
    }

    // Close the database connection
    mysqli_close($conn);
    ?>
</body>

</html>
