<!DOCTYPE html>
<html lang="en">

<head>
    <title>Year 3 Results Table</title>
    <link rel="stylesheet" href="assets/css/php.css">
    
</head>

<body>

<center><h1>Team 1 Results Year 3</h1></center>
<p style="text-align: center; font-weight: bold;">The sheet displays the events trigerred during the year and the assets affected,
the boxes selected are the assets that were protected from the events.</p>

    <?php
    ini_set('display_errors', 1);
    error_reporting(E_ALL);

    // Database credentials
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $database = "game";
    $port = "3306";

    // Create a database connection
    $conn = mysqli_connect($hostname, $username, $password, $database, $port);

    // Check if the connection was successful
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    //Procedure to calculate Asset Value losses
    $procedure="CALL loss_year3_team1()";
    $result = mysqli_query($conn, $procedure);

    // Fetch Year 2 results data from the database
    $query = "Select p.Policy_Desciption_Perils_covered,i.Asset,i.Asset_Name,i.Policy_Selection_Team_1 from input_sheet_year3 i NATURAL JOIN perilsheet p NATURAL JOIN eventtrigger e where e.Round_3=1 and e.Risk_Event=p.Policy_Desciption_Perils_covered;";
    $result = mysqli_query($conn, $query);

    // Generate HTML table rows dynamically
    echo "<table>";
    echo "<thead>";
    echo "<tr>";
    echo "<th>Event Triggered</th>";
    echo "<th>Asset Code</th>";
    echo "<th>Asset Affected</th>";
    echo "<th>Asset Protected?</th>";
    echo "</tr>";
    echo "</thead>";
    echo "<tbody>";

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row['Policy_Desciption_Perils_covered'] . "</td>";
            echo "<td>" . $row['Asset'] . "</td>";
            echo "<td>" . $row['Asset_Name'] . "</td>";
            echo "<td>";
            if ($row['Policy_Selection_Team_1'] == 1) {
                echo '<input type="checkbox" checked disabled>';
            } else {
                echo '<input type="checkbox" disabled>';
            }
            echo"</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='5'>No records found</td></tr>";
    }

    echo "</tbody>";
    echo "</table>";

    echo "<center>";
    echo "<form action='year3resultsteam2.php' method='post'>";
    echo "<input type='submit' name='submit' value='Submit'>"; 
    echo "</form>";
    echo "</center>";

    // Close the database connection
    mysqli_close($conn);
    ?>
</body>

</html>
