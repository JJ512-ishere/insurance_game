<!DOCTYPE html>
<html lang="en">

<head>
    <title>Input Sheet Year 1 Table</title>
    
</head>

<body>

    <?php
    ini_set('display_errors', 1);
    error_reporting(E_ALL);

    // Database credentials
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $database = "game";
    $port = "3306";

    // Create a database connection
    $conn = mysqli_connect($hostname, $username, $password, $database, $port);

    // Check if the connection was successful
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Fetch input sheet year 1 data from the database
    $query = "SELECT * FROM Input_Sheet_Year1";
    $result = mysqli_query($conn, $query);

    // Generate HTML table rows dynamically
    echo "<table>";
    echo "<thead>";
    echo "<tr>";
    echo "<th>Policy Code</th>";
    echo "<th>Policy Description/Perils Covered</th>";
    echo "<th>Asset</th>";
    echo "<th>Asset Name</th>";
    echo "<th>Premium</th>";
    echo "<th>Policy Selection Team 1</th>";
    echo "<th>Policy Selection Team 2</th>";
    echo "</tr>";
    echo "</thead>";
    echo "<tbody>";

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row['Policy_Code'] . "</td>";
            echo "<td>" . $row['Policy_Desciption_Perils_covered'] . "</td>";
            echo "<td>" . $row['Asset'] . "</td>";
            echo "<td>" . $row['Asset_Name'] . "</td>";
            echo "<td>" . $row['Premium'] . "</td>";
            echo "<td>" . $row['Policy_Selection_Team_1'] . "</td>";
            echo "<td>" . $row['Policy_Selection_Team_2'] . "</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='7'>No records found</td></tr>";
    }

    echo "</tbody>";
    echo "</table>";

    // Close the database connection
    mysqli_close($conn);
    ?>
</body>

</html>
