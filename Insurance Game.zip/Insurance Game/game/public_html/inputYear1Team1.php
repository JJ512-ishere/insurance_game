<!DOCTYPE html>
<html lang="en">

<head>
    <title>Input Sheet Year 1 Table</title>
    <link rel="stylesheet" href="assets/css/php.css">
    
    <style>
        /* .circle-button {
            width: 20px;
            height: 20px;
            border-radius: 50%;
            border: 1px solid #000;
            background-color: white; 
        } */
        .container {
            text-align: right; /* Aligns content to the right */
            padding: 20px; /* Adds some space around the content */
        }
        .submit-button {
             margin-right: 20px; /* Adds space between the button and other content */
        }

    </style>
</head>

<body>
    
<center><h1>Team 1 Input Year 1</h1></center>

<p style="text-align: center; font-weight: bold;">Please select the policies for Year 1, based on the study of the previous
    sheets.Remember to strategize and allocate the premium across the asset base and maximize the Net Asset Value.</p>

    <?php
    ini_set('display_errors', 1);
    error_reporting(E_ALL);

    // Database credentials
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $database = "game";
    $port = "3306";

    // Create a database connection
    $conn = mysqli_connect($hostname, $username, $password, $database, $port);

    // Check if the connection was successful
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }


    // Fetch input sheet year 1 data from the database
    $query = "SELECT Policy_Code,Policy_Desciption_Perils_covered,Asset,Asset_Name,Premium,Policy_Selection_Team_1 FROM Input_Sheet_Year1 order by Policy_Desciption_Perils_covered";
    $result = mysqli_query($conn, $query);


    // Generate HTML table rows dynamically
    echo "<form method='post' action=''>";
    echo "<table>";
    echo "<thead>";
    echo "<tr>";
    echo "<th>Policy Code</th>";
    echo "<th>Policy Description/Perils Covered</th>";
    echo "<th>Asset</th>";
    echo "<th>Asset Name</th>";
    echo "<th>Premium</th>";
    echo "<th>Policy Selection Team 1</th>";
    echo "</tr>";
    echo "</thead>";
    echo "<tbody>";

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row['Policy_Code'] . "</td>";
            echo "<td>" . $row['Policy_Desciption_Perils_covered'] . "</td>";
            echo "<td>" . $row['Asset'] . "</td>";
            echo "<td>" . $row['Asset_Name'] . "</td>";
            echo "<td>" . $row['Premium'] . "</td>";
            echo "<td><input type='checkbox' name='policy[]' value='" . $row['Policy_Code'] . "'></td>";

            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='7'>No records found</td></tr>";
    }

    echo "</tbody>";
    echo "</table>";
    echo "<br>";
    echo "<input type='submit' name='update' value='Choose Selected Policies'>";
    echo "</form>";

    echo "<center>";
    echo "<form action='inputYear1Team2.php' method='post'>";
    echo "<input type='submit' name='submit' value='Submit'>"; 
    echo "</form>";
    echo "</center>";

    echo "<div class='container'>";
    echo "<form action='balanceTeam1.php' method='post'>";
    echo "<input type='submit' name='Balance' value='Balance' class='submit-button'>"; 
    echo "</form>";
    echo "</div>";

    

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
        $selectedIds = $_POST['policy'];

        foreach ($selectedIds as $id) {

            $check="SELECT Policy_Selection_Team_1 from Input_Sheet_Year1 where Policy_Code='$id'";
            $res= mysqli_query($conn, $check);
            $pol=mysqli_fetch_assoc($res);

            if($pol['Policy_Selection_Team_1']== 0){
            $q1="SELECT Premium from Input_Sheet_Year1 where Policy_Code='$id'";
            $results = mysqli_query($conn, $q1);
            $prem=mysqli_fetch_assoc($results);

            $q2="SELECT bal from balance where Team_Code='T1'";
            $results1 = mysqli_query($conn, $q2);
            $bal=mysqli_fetch_assoc($results1);

            if($bal['bal'] < $prem['Premium']){
                echo '<div style="background-color: red; color: white; text-align: center; padding: 10px;">';
                echo "Insufficent Funds to Purchase Policy";
                echo '</div>';
            }

            else{
            $query1 = "UPDATE Input_Sheet_Year1 SET Policy_Selection_Team_1=1 WHERE Policy_Code='$id'";
            $result = mysqli_query($conn, $query1);
            $procedure="CALL choose_policy_year1_team1('$id')";
            $result= mysqli_query($conn, $procedure); 
            }
            }
            else{
                echo '<div style="background-color: red; color: white; text-align: center; padding: 10px;">';
                echo "Policy '$id' is already selected";
                echo '</div>';
                continue;
            }
        }
    }
   
    // Close the database connection
    mysqli_close($conn);

    
    ?>

</body>

</html>
