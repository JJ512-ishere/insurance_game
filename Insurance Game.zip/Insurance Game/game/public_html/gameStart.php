<!DOCTYPE html>
<html lang="en">

    <head>

        <title>Insurance Game</title>
        <!-- font icons -->
        <link rel="stylesheet" href="assets/vendors/themify-icons/css/themify-icons.css">

        <link rel="stylesheet" href="assets/css/main_css.css">

    </head>

    <body data-spy="scroll" data-target=".navbar" data-offset="40" id="home" class="dark-theme">

        <!-- page navbar -->
        <nav class="page-navbar" data-spy="affix" data-offset-top="10">
        </nav><!-- end of page navbar -->

        <div class="theme-selector">
            <a href="javascript:void(0)" class="spinner">
                <i class="ti-paint-bucket"></i>
            </a>
            <div class="body">
                <a href="javascript:void(0)" class="light"></a>
                <a href="javascript:void(0)" class="dark"></a>
            </div>
        </div>

        <!-- page container -->
        <div class="container page-container">
            <div class="col-md-10 col-lg-8 m-auto">
                <p class="mb-5">Master Insurance Broker is an immersive game that challenges players to
                    protect assets effectively
                    in the face of limited premiums. Strategically allocate premiums across diverse asset classes,
                    navigate risks, and adapt to
                    changing market dynamics. Dive into insurance contract intricacies and guide clients to financial
                    security.
                    Enhance your strategic thinking and analytical skills in this realistic simulation. </p>
                <p>Click below to explore different cases and utilize unique data to become the ultimate insurance
                    broker!
                </p>
            </div>


            <!-- row -->
            <div class="row mb-4">
                <div class="col-md-4">
                    <a href="assetAllocation.php" class="overlay-img">
                        <img src="assets/imgs/temp1.jpeg" alt="Image representing Asset Allocation sheet">
                        <div class="overlay"></div>
                        <div class="des">
                            <h1 class="title">Asset Allocation</h1>
                            <h6 class="subtitle">Protecting assets across geographical areas</h6>
                            <p>This sheet provides the list of all assets across various geographical areas that need to
                                be protected against natural catastrophic events. Each team will receive this sheet for
                                their reference and decision-making.</p>
                        </div>
                    </a>
                </div>
            </div><!-- end of row -->



            <div class="col-md-4">
                <a href="javascript:void(0)" class="overlay-img">
                    <img src="assets/imgs/temp2.jpeg" alt="Image representing Peril Sheet">
                    <div class="overlay"></div>
                    <div class="des">
                        <h1 class="title">Peril Sheet</h1>
                        <h6 class="subtitle">Listing perils associated with each asset</h6>
                        <p>This sheet contains the list of all perils associated with each asset. Teams can refer to
                            this sheet to understand the risks and vulnerabilities of their assets.</p>
                    </div>
                </a>
            </div>
            <div class="col-md-4">
                <a href="javascript:void(0)" class="overlay-img">
                    <img src="assets/imgs/temp3.jpeg" alt="Image representing Probability Distribution">
                    <div class="overlay"></div>
                    <div class="des">
                        <h1 class="title">Probability Distribution</h1>
                        <h6 class="subtitle">Event occurrence pattern for perils</h6>
                        <p>This sheet provides a 100-year event occurrence pattern for each peril in each city.
                            Teams can refer to this sheet to analyze the probability of different events happening
                            over time.</p>
                    </div>
                </a>
            </div>
            <div class="col-md-4">
                <a href="javascript:void(0)" class="overlay-img">
                    <img src="assets/imgs/temp4.jpeg" alt="Image representing Input Sheet for Year 1">
                    <div class="overlay"></div>
                    <div class="des">
                        <h1 class="title">Input Sheet - Year 1</h1>
                        <h6 class="subtitle">Policy selection for the first year</h6>
                        <p>This sheet contains the input for policy selection in the first year. Teams need to
                            choose the policies they wish to procure within the specified budget. It helps in
                            managing risk and protecting the assets.</p>
                    </div>
                </a>
            </div>
            <div class="col-md-4">
                <a href="javascript:void(0)" class="overlay-img">
                    <img src="assets/imgs/temp5.jpeg" alt="Image representing Results for Year 1">
                    <div class="overlay"></div>
                    <div class="des">
                        <h1 class="title">Year 1 Results</h1>
                        <h6 class="subtitle">Cumulative asset value for the first year</h6>
                        <p>This sheet calculates the total asset value for the team based on the events triggered
                            and policies chosen in the first year. It helps in assessing the team's performance and
                            progress.</p>
                    </div>
                </a>
            </div>
            <div class="col-md-4">


                <a href="javascript:void(0)" class="overlay-img">
                    <img src="assets/imgs/temp6.jpeg" alt="Image representing Input Sheet for Year 2">
                    <div class="overlay"></div>
                    <div class="des">
                        <h1 class="title">Input Sheet - Year 2</h1>
                        <h6 class="subtitle">Policy selection for the second year</h6>
                        <p>This sheet contains the input for policy selection in the second year. Teams need to
                            choose the policies they wish to procure within the specified budget. It helps in
                            managing risk and protecting the assets.</p>
                    </div>
                </a>
            </div>
            <div class="col-md-4">
                <a href="javascript:void(0)" class="overlay-img">
                    <img src="assets/imgs/temp7.jpeg" alt="Image representing Results for Year 2">
                    <div class="overlay"></div>
                    <div class="des">
                        <h1 class="title">Year 2 Results</h1>
                        <h6 class="subtitle">Cumulative asset value for the second year</h6>
                        <p>This sheet calculates the total asset value for the team based on the events triggered
                            and policies chosen in the second year. It helps in assessing the team's performance and
                            progress.</p>
                    </div>
                </a>
            </div>
        </div><!-- end of row -->
    </body>

</html>