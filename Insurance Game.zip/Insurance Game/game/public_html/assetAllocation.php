
<!DOCTYPE html>
<html lang="en">


<head>
    <title>Asset Allocation Table</title>
    <!-- Add any necessary CSS or styling -->
    <link rel="stylesheet" href="assets/css/php.css">
</head>


<body>
    <h1>Asset Allocation Table</h1>

    <?php
    // Database credentials
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $database = "game";
    $port = "3306";

    // Create a database connection
    $conn = mysqli_connect('localhost', 'root', '', 'game',3306);

    // Check if the connection was successful
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Fetch asset allocation data from the database
    $query = "SELECT * FROM AssetAllocation";
    $result = mysqli_query($conn, $query);

    // Generate HTML table rows dynamically
    echo "<table>";
    echo "<thead>";
    echo "<tr>";
    echo "<th>Asset</th>";
    echo "<th>Location</th>";
    echo "<th>Value</th>";
    echo "<th>Life</th>";
    echo "<th>ACode</th>";
    echo "</tr>";
    echo "</thead>";
    echo "<tbody>";

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row['asset'] . "</td>";
            echo "<td>" . $row['location'] . "</td>";
            echo "<td>" . $row['value'] . "</td>";
            echo "<td>" . $row['life'] . "</td>";
            echo "<td>" . $row['acode'] . "</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='5'>No records found</td></tr>";
    }

    echo "</tbody>";
    echo "</table>";

    // Close the database connection
    mysqli_close($conn);
    ?>
    <center>
    <button onclick="goBack()">Back</button>
    </center>

    <script>
    function goBack() {
    window.history.back(); // This navigates back to the previous page in the browser's history
    }
    </script>
</body>

</html>
