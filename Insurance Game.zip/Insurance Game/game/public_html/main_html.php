<!DOCTYPE html>
<html lang="en">

<head>
    <title>Insurance Game</title>
    <!-- font icons -->
    <link rel="stylesheet" href="assets/vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/main_css.css">
</head>

<body data-spy="scroll" data-target=".navbar" data-offset="40" id="home" class="dark-theme">
    <!-- page navbar -->
    <nav class="page-navbar" data-spy="affix" data-offset-top="10"></nav><!-- end of page navbar -->

    <div class="theme-selector">
        <a href="javascript:void(0)" class="spinner">
            <i class="ti-paint-bucket"></i>
        </a>
        <div class="body">
            <a href="javascript:void(0)" class="light"></a>
            <a href="javascript:void(0)" class="dark"></a>
        </div>
    </div>

    <!-- page header -->
    <header class="header">
        <div class="overlay"></div>
        <div class="header-content">
            <h1 class="header-title">Become the Master Insurance Broker:
                Navigate Risk and Protect Assets</h1>
            <p class="header-subtitle">Protect assets, maximize value. Strategize, allocate, and
                choose policies wisely. Navigate risks, uncertainty, and changing markets.
                Win by safeguarding assets and achieving the highest cumulative value in five years.
                Are you up for the challenge? Play now!</p>
            <form id="teamForm">
                <label for="team1">Team 1:</label>
                <input type="text" id="team1" name="team1" required>
                <label for="team2">Team 2:</label>
                <input type="text" id="team2" name="team2" required>
            </form>
            <br>
            <button id="startGameBtn">Start Game</button>
        </div>
    </header><!-- end of page header -->

    <!-- JavaScript -->
    <script>
        // Get form and button elements
        const teamForm = document.getElementById('teamForm');
        const startGameBtn = document.getElementById('startGameBtn');

        // Add event listener to the start game button
        startGameBtn.addEventListener('click', function(event) {
            event.preventDefault(); // Prevent form submission

            // Get the team names from the form inputs
            const team1Name = document.getElementById('team1').value;
            const team2Name = document.getElementById('team2').value;

            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'main_html.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        
            xhr.onreadystatechange = function() {
                if (xhr.readyState === XMLHttpRequest.DONE) {
                    if (xhr.status === 200) {
                        document.getElementById('result').textContent = xhr.responseText;
                    } else {
                        // Handle error
                    }
                }
            };
        
        var data = 'team1=' + encodeURIComponent(team1Name) + '&team2=' + encodeURIComponent(team2Name);
        xhr.send(data);

         // Validate team names
         if (team1Name.trim() !== '' && team2Name.trim() !== '') {
                // Redirect to the game start page with the team names as URL parameters
                window.location.href = `gamestart.html?team1=${encodeURIComponent(team1Name)}&team2=${encodeURIComponent(team2Name)}`;
            }

            
        });
    </script>

    <?php
    if (isset($_POST['team1']) && isset($_POST['team2'])) {
        $input1 = $_POST['team1'];
        $input2 = $_POST['team2'];


        ini_set('display_errors', 1);
        error_reporting(E_ALL);

        // Database credentials
        $hostname = "localhost";
        $username = "root";
        $password = "";
        $database = "game";
        $port = "3306";

        // Create a database connection
        $conn = mysqli_connect($hostname, $username, $password, $database, $port);

        // Check if the connection was successful
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        $procedure="CALL start_game('$input1','$input2')";
        $result = mysqli_query($conn, $procedure);

        mysqli_close($conn);
    }
    ?>
</body>

</html>