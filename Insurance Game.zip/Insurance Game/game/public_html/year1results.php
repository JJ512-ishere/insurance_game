<!DOCTYPE html>
<html lang="en">

<head>
    <title>Year 1 Results Table</title>
    <link rel="stylesheet" href="assets/css/php.css">
    
</head>

<body>

<center><h1>Team 1 Results Year 1</h1></center>

    <?php
    ini_set('display_errors', 1);
    error_reporting(E_ALL);

    // Database credentials
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $database = "game";
    $port = "3306";

    // Create a database connection
    $conn = mysqli_connect($hostname, $username, $password, $database, $port);

    // Check if the connection was successful
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Fetch Year 1 results data from the database
    $query = "SELECT * FROM Year1_Results";
    $result = mysqli_query($conn, $query);

    // Generate HTML table rows dynamically
    echo "<table>";
    echo "<thead>";
    echo "<tr>";
    echo "<th>Risk Event</th>";
    echo "<th>Peril</th>";
    echo "<th>Asset</th>";
    echo "<th>Results Team 1</th>";
    echo "<th>Results Team 2</th>";
    echo "</tr>";
    echo "</thead>";
    echo "<tbody>";

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row['Risk_Event'] . "</td>";
            echo "<td>" . $row['Peril'] . "</td>";
            echo "<td>" . $row['Asset'] . "</td>";
            echo "<td>" . $row['Results_Team1'] . "</td>";
            echo "<td>" . $row['Results_Team2'] . "</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='5'>No records found</td></tr>";
    }

    echo "</tbody>";
    echo "</table>";

    // Close the database connection
    mysqli_close($conn);
    ?>
</body>

</html>
